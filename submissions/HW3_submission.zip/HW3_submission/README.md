Source for mesh for custom scene: https://www.cgtrader.com/free-3d-models/household/other/residential-building-e8e9f7cd-db43-4e38-a271-621e65dd0a2f

The custom render is in "custom.png". It's an attempt to simulate "apocalyptic" lighting, with an orange sky and yellowish-orange light on a building.

Moving lighting bonus implemented. It is in "moving light.webm".
