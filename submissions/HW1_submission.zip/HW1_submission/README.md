Submission for Sumukh Murthy (A17315062)

- output renders are in /outputs
- custom scene render is at /outputs/custom.png
- custom scene is defined in /scenes/hw1/bowshot.json

I have implemented the bounding box bonus for part 1.2. Without the bounding box, scene 0 took 0.0168403 seconds to draw. After the bounding box, it takes 0.00969308 seconds - a significant improvement.
