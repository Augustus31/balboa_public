Source for mesh for custom scene: https://sketchfab.com/3d-models/hatchet-cf9df43de1f740f08aa2e70efd225256

I added vertex colors myself to make the axe appear realistic (using a parser I wrote in Java). The custom render is in outputs/custom.png.

No bonuses implemented.
